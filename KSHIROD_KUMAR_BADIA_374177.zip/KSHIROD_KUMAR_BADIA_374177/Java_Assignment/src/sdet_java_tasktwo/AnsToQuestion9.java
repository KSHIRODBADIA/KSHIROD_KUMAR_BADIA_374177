package sdet_java_tasktwo;

public class AnsToQuestion9 {

	public static void main(String[] args) {
		 char ch = 'c';
	        String st = Character.toString(ch);
	        // Alternatively
	        // st = String.valueOf(ch);

	        System.out.println("The string is: " + st);

	}

}
