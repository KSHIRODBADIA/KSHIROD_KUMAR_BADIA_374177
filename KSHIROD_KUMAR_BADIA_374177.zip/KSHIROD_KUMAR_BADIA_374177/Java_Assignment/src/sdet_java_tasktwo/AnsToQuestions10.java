package sdet_java_tasktwo;

import java.util.Arrays;
import java.util.Collections;

public class AnsToQuestions10 {
	 // Method returns sum of maximum of all subsets 
    static int sumOfMaximumOfSubsets(Integer arr[], int N)  
    { 
        // sorting array in decreasing order 
        Arrays.sort(arr, Collections.reverseOrder()); 
  
        // initializing sum with first element 
        int sum = arr[0]; 
        for (int i = 1; i < N; i++) 
        { 
            // calculating evaluation similar to horner's rule 
            sum = 2 * sum + arr[i]; 
        } 
  
        return sum; 
    } 
	public static void main(String[] args) {
		// 10. Regar and Heaps 
		/*Regar likes to play with Heaps a lot. One day, he had an array A holding N numbers. He was interested in subsets of size K. He made all possible subsets of size K from the array A. For each subset, he calculated sum elements and inserted the value of sum into a min−Heap. 
		Krankit, his mischievous neighbour, popped out (M−1) elements from the min-Heap while Regar was busy having snacks. Now, Regar came after having snacks and popped out one element from the min-Heap expecting the minimum possible number but he became sad as soon as he realized that he obtained the wrong result. 
		Help him by telling the amount which he needs to subtract to get the correct result. 
*/
		 Integer arr[] = {3, 2, 5}; 
	        int N = arr.length; 
	        System.out.println(sumOfMaximumOfSubsets(arr, N)); 
 }
}