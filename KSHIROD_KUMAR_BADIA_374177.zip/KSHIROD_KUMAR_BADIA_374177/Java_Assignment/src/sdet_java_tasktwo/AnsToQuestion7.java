package sdet_java_tasktwo;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AnsToQuestion7 {

	public static void main(String[] args) throws ParseException {
		 String sDate1="31/12/1998";  
		    Date date1=(Date) new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);  
		    System.out.println(sDate1+"\t"+date1);

	}

}
