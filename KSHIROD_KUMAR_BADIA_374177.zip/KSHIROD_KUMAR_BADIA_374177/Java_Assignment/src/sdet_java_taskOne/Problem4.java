package sdet_java_taskOne;

import java.util.Scanner;

public class Problem4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two number");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		//int num1= 10;
		//int num2= 20;
		System.out.println("Your first number "+num1);
		System.out.println("Your second number "+num2);
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("After swipe your first number "+num1);
		System.out.println("After swipe your second number "+num2);
	}

}
