package core_java_assignment_answers;

import java.util.Scanner;

public class Question7 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input a Decimal number");
		String x = sc.next();
		int n1=Integer.parseInt(x, 10);
		System.out.println("Binary number is: "+Integer.toBinaryString(n1));
	}

}
