package core_java_assignment_answers;

public class Question2 {

	public static void main(String[] args) {
		//a. -5 + 8 * 6 
		int a=-5, b=8, c=6;
		int d=a+b*c;
		System.out.println(d);
		//b. (55+9) % 9
		int x=55, y=9, z=9;
		int f=(x+y)%z;
		System.out.println(f);
		//c. 20 + -3*5 / 8  
		int a1=20, b1=-3, c1=5, d1=8;
		int e1=a1+b1*c1/d1;
		System.out.println(e1);
		//d. 5 + 15 / 3 * 2 - 8 % 3
		int a2=15, b2=3, c2=2, d2=8;
		int res= c1+a2/b2*c2-d2%b2;
		System.out.println(res);

	}

}
