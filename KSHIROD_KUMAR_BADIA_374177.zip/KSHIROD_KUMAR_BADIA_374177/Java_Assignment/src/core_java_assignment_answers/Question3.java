package core_java_assignment_answers;

import java.util.Scanner;

public class Question3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input first number");
		int a = sc.nextInt();
		System.out.println("Input second number");
		int b = sc.nextInt();
		System.out.println("Inputed first number:"+a);
		System.out.println("Inputed second number:"+b);
		int c=a+b;
		int d=a-b;
		int e=a*b;
		int f=a/b;
		int g=a%b;
		System.out.println(a+"+"+b+"="+c);
		System.out.println(a+"-"+b+"="+d);
		System.out.println(a+"*"+b+"="+e);
		System.out.println(a+"/"+b+"="+f);
		System.out.println(a+"mod"+b+"="+g);
	}

}
