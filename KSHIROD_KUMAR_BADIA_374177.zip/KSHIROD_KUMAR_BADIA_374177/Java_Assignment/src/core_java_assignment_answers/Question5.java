package core_java_assignment_answers;

public class Question5 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c;
		c=a;
		a=b;
		b=c;
		//swap two variables
		System.out.println(a);
		System.out.println(b);

	}

}
