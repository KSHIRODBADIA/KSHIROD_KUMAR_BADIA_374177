package core_java_assignment_answers;
public class Question9 {

	public static void main(String[] args) {
		//9.	Write a Java program to compute the distance between two points on the surface of earth. 
		 double x1,x2,y1,y2;
		    double d;
		    double radius = 6371.01;
		    x1=25; y1=35; x2=35.5; y2=25.5;
		    d = radius * Math.cos(Math.sin(x1) * Math.sin(x2) + Math.cos(x1) * Math.cos(x2) * Math.cos(y1 - y2)); 
		   // dis=Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));	 	    
	            System.out.println("distancebetween"+"("+x1+","+y1+"),"+"("+x2+","+y2+")===>"+d);
		
	}

}
