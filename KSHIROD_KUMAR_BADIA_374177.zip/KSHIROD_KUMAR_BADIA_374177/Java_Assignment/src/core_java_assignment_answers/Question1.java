package core_java_assignment_answers;

public class Question1 {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println("Kshirod Kumar Badia");

	}

}
