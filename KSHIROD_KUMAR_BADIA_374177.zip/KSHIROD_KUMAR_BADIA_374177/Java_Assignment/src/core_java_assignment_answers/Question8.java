package core_java_assignment_answers;

import java.util.Scanner;

public class Question8 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input a number");
		int num = sc.nextInt();
		//int num=25;
		int rem=0;
		int sum=0;
		while(num!=0) {
			rem=num%10;
			sum=sum+rem;
			num=num/10;
		}
		System.out.println("The sum of the digit is: "+sum);
	}

}
