package sdet_java_taskfour;

public class Problems10 {
	static double findMod(double a, double b) 
    { 
        // Handling negative values 
        if (a < 0) 
            a = -a; 
        if (b < 0) 
            b = -b; 
      
        // Finding mod by repeated subtraction 
        double mod = a; 
        while (mod >= b) 
            mod = mod - b; 
      
        // Sign of result typically depends 
        // on sign of a. 
        if (a < 0) 
            return -mod; 
      
        return mod; 
    } 
	public static void main(String[] args) {
		// 10. Micro and Modulo�Micro's math teacher just taught him about Modular�Arithmetic, and�gave him an assignment to solve. Assignment is�really large�and will take a lot of his time. Micro wants to go out and play as soon as possible. The assignment consists of some decimal numbers and Micro has to find out the value of�their�modulo 10^9+7. Help Micro complete this assignment.�
		double a = 9.7, b = 2.3; 
        System.out.print(findMod(a, b)); 
	}

}
